<?php
/**
 * 2017-2019 Zemez
 *
 * JX Manufacturers block
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 * @author    Zemez (Alexander Grosul)
 * @copyright 2017-2019 Zemez
 * @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */

class JXManufacturersSettingsRepository
{
    private $db;
    private $shop;
    private $db_prefix;
    public $settingsList = array(
        'JX_MANUFACTURER_DISPLAY_NAME' => 0,
        'JX_MANUFACTURER_ORDER' => 0,
        'JX_MANUFACTURER_DISPLAY_IMAGE' => 0,
        'JX_MANUFACTURER_DISPLAY_IMAGE_TYPE' => '',
        'JX_MANUFACTURER_DISPLAY_ITEM_NB' => 4,
        'JX_MANUFACTURER_DISPLAY_CAROUCEL' => 0,
        'JX_MANUFACTURER_CAROUCEL_NB' => 4,
        'JX_MANUFACTURER_CAROUCEL_SLIDE_MARGIN' => 20,
        'JX_MANUFACTURER_CAROUCEL_AUTO' => 0,
        'JX_MANUFACTURER_CAROUCEL_ITEM_SCROLL' => 1,
        'JX_MANUFACTURER_CAROUCEL_SPEED' => 500,
        'JX_MANUFACTURER_CAROUCEL_AUTO_PAUSE' => 3000,
        'JX_MANUFACTURER_CAROUCEL_LOOP' => 1,
        'JX_MANUFACTURER_CAROUCEL_HIDE_CONTROL' => 1,
        'JX_MANUFACTURER_CAROUCEL_PAGER' => 0,
        'JX_MANUFACTURER_CAROUCEL_CONTROL' => 0
    );

    public function __construct(Db $db, Shop $shop)
    {
        $this->db = $db;
        $this->shop = $shop;
        $this->db_prefix = $db->getPrefix();
    }

    public function createTables()
    {
        $engine = _MYSQL_ENGINE_;
        $success = true;
        $this->dropTables();

        $queries = [
            "CREATE TABLE IF NOT EXISTS `{$this->db_prefix}jxmanufacturers_settings`(
    			`id_setting` int(10) unsigned NOT NULL auto_increment,
    			`hook_name` VARCHAR (100),
    			`id_shop` int(10) unsigned,
    			`setting_name` VARCHAR (100),
    			`value` VARCHAR (100),
    			PRIMARY KEY (`id_setting`, `hook_name`, `id_shop`)
            ) ENGINE=$engine DEFAULT CHARSET=utf8"];

        foreach ($queries as $query) {
            $success &= $this->db->execute($query);
        }

        return $success;
    }

    public function dropTables()
    {
        $sql = "DROP TABLE IF EXISTS
			`{$this->db_prefix}jxmanufacturers_settings`";

        return Db::getInstance()->execute($sql);
    }

    public function setDefaultSettings($hookName) {
        $result = true;
        foreach ($this->settingsList as $name => $value) {
            $result &= $this->db->insert('jxmanufacturers_settings', array('hook_name' => pSQL($hookName), 'id_shop' => (int)$this->shop->id, 'setting_name' => pSQL($name), 'value' => pSQL($value)));
        }

        return $result;
    }

    public function getSetting($hookName, $settingName)
    {
        return $this->db->getValue(
            "SELECT `value`
            FROM `{$this->db_prefix}jxmanufacturers_settings`
            WHERE `hook_name` = '".pSQL($hookName)."'
            AND `setting_name` = '".pSQL($settingName)."'
            AND `id_shop` = ".(int)$this->shop->id
        );
    }

    public function getSettings($hookName = false, $result = [])
    {
        $query = "SELECT `setting_name`, `value`
            FROM `{$this->db_prefix}jxmanufacturers_settings`
            WHERE `id_shop` = ".(int)$this->shop->id;
            
        if ($hookName) {
            $query .= " AND `hook_name` = '".pSQL($hookName)."'";
        }

        $settings = $this->db->executeS($query);

        if ($settings) {
            foreach ($settings as $setting) {
                $result[$setting['setting_name']] = $setting['value'];
            }
        }

        return $result;
    }

    public function checkSetting($hookName, $settingName)
    {
        return $this->db->getValue(
            "SELECT `id_setting`
            FROM `{$this->db_prefix}jxmanufacturers_settings`
            WHERE `hook_name` = '".pSQL($hookName)."'
            AND `setting_name` = '".pSQL($settingName)."'
            AND `id_shop` = ".(int)$this->shop->id
        );
    }

    public function insertSetting($hookName, $settingName, $value)
    {
        return $this->db->insert('jxmanufacturers_settings', array('hook_name' => pSQL($hookName), 'id_shop' => (int)$this->shop->id, 'setting_name' => pSQL($settingName), 'value' => pSQL($value)));
    }

    public function updateSetting($hookName, $settingName, $value)
    {
        if ($this->checkSetting($hookName, $settingName)) {
            return $this->db->update(
                'jxmanufacturers_settings', array('value' => pSQL($value)),
                '`hook_name` = "'.pSQL($hookName).'" AND `setting_name` = "'.pSQL($settingName).'"'
            );
        } else {
            return $this->insertSetting($hookName, $settingName, $value);
        }
    }
}
