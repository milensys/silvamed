# JX Blog Post Products

V 0.0.4
UPD: removed Translator parameter from Repository class in order to reach compatibility with PS 1.7.6.1

V 0.0.3
 - fixed an issue with the absence of token in ajax query URL during instant product search

V 0.0.2
FIX:
 - fixed a jquery issue on the admin post page when a product ID doesn't exists