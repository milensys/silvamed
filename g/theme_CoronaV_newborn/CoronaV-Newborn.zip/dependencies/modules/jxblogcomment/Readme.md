# JX Blog Comment

v 0.1.3
UPD: removed Translator parameter from Repository class in order to reach compatibility with PS 1.7.6.1

v 0.1.2
FIX: fixed an issue with front-end comments tree if one of comments has children and is disabled

v 0.1.1
FIX: fixed an issue with commenting when a GDPR module is disabled

v 0.1.0
Added compatibility with GDPR module