# JX Blog

v 1.1.2
UPD: removed Translator parameter from Repository class in order to reach compatibility with PS 1.7.6.1

v 1.1.1
UPD: admin tab management improved
FIX:
 - fixed an issue with duplicating post categories if pick default category the same as one of the related
 - fixed an issue with a searching through the JX Blog


v 1.1.0
UPD: - added an opportunity to create and use multilevel categories with no depth limit
     - added compatibility to support new feature in posts

v 1.0.2
FIX:
 - added notification that only .jpg images are allowed for categories
 - added cache removing for post thumbnails preview

v 1.0.1
FIX:
 - added workaround to avoid an issue with breadcrumbs items translation

1.0.0
UPD:
 - tested all features
 - added new blog home page option with new template and controller

0.0.2
FIX: fixed an issue with PHP 7 compatibility(admin part). An error with setMedia conformity