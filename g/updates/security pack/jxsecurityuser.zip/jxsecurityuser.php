<?php
/**
 * 2017-2018 Zemez
 *
 * JX Security User
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 *  @author    Zemez
 *  @copyright 2017-2018 Zemez
 *  @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once _PS_MODULE_DIR_ . 'jxsecurityuser/libs/CIDR.php';
include_once _PS_MODULE_DIR_ . 'jxsecurityuser/classes/JxSecurityPanelBlacklist.php';
include_once _PS_MODULE_DIR_ . 'jxsecurityuser/classes/JxSecurityPanelLoginFail.php';

class Jxsecurityuser extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'jxsecurityuser';
        $this->tab = 'administration';
        $this->version = '1.0.2';
        $this->author = 'Zemez';
        $this->need_instance = 1;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('JX Security User');
        $this->description = $this->l('Security module for your shop.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall my module?');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->ajax_controller = 'AdminJxSecurityUser';
    }

    public function install()
    {
        if ($this->checkTableExists()) {
            $query = "INSERT INTO `"._DB_PREFIX_."jxsecuritypanel` (`module`, `name`) 
                      VALUES ('jxsecurityuser', 'Users')";
            Db::getInstance()->execute($query);
        }

        include(dirname(__FILE__) . '/sql/install.php');

        return parent::install() &&
            $this->installTab() &&
            $this->updateSettings($this->getDefaultSettings()) &&
            $this->registerHook('header') &&
            $this->registerHook('actionAuthenticationBefore') &&
            $this->registerHook('actionBeforeAuthentication') &&
            $this->registerHook('displayCustomerLoginFormAfter') &&
            $this->registerHook('backOfficeHeader');
    }

    public function uninstall()
    {
        if ($this->checkTableExists()) {
            $query = "DELETE FROM `"._DB_PREFIX_."jxsecuritypanel` 
                      WHERE `module` = 'jxsecurityuser';";

            Db::getInstance()->execute($query);
        }
        include(dirname(__FILE__) . '/sql/uninstall.php');

        return parent::uninstall() &&
            $this->uninstallTab();
    }

    protected function installTab()
    {
        $tab = new Tab();

        $this->active = 1;
        $langs = Language::getLanguages(false);
        if (is_array($langs)) {
            foreach ($langs as $lang) {
                $tab->name[$lang['id_lang']] = 'jxsecurityuser';
            }
        }

        $tab->class_name = 'AdminJxSecurityUser';
        $tab->module = $this->name;
        $tab->id_parent = -1;

        return (bool)$tab->add();
    }

    protected function uninstallTab()
    {
        if ($id = (int)Tab::getIdFromClassName('AdminJxSecurityUser')) {
            $tab = new Tab($id);
            $tab->delete();
        }

        return true;
    }

    protected function checkTableExists()
    {
        $tables = Db::getInstance()->executeS("SHOW TABLES");

        if (is_array($tables)) {
            foreach ($tables as $table) {
                if (in_array(_DB_PREFIX_.'jxsecuritypanel', $table)) {
                    return true;
                }
            }
        }

        return false;
    }

    public function getDefaultSettings()
    {
        return array(
            'JXSECURITY_LOGINFAIL_BLOCK' => 0,
            'JXSECURITY_LOGINFAIL_DISABLE' => 0,
            'JXSECURITY_LOGINFAIL_MESSAGE' => 0
        );
    }

    public function getSettings($configs)
    {
        foreach (array_keys($configs) as $key) {
            $configs[$key] = Configuration::get($key);
        }

        return $configs;
    }

    public function updateSettings($configs)
    {
        foreach ($configs as $key => $value) {
            Configuration::updateValue($key, $value);
        }

        return true;
    }

    public function deleteSettings($configs)
    {
        foreach (array_keys($configs) as $value) {
            Configuration::deleteByName($value);
        }

        return true;
    }

    public function getContent()
    {
        $this->context->smarty->assign(array(
            'configs' => $this->getSettings($this->getDefaultSettings()),
            'uri' => $this->context->link->getAdminLink($this->ajax_controller),
            'customers' => $this->getCustomersOnline(),
            'visitors' => $this->getVisitorsOnline(),
            'login_fail' => $this->getLoginFail(),
            'blacklist' => $this->getBlacklist(),
            'banlist' => $this->getBanlist()
        ));
        return $this->context->smarty->fetch($this->local_path.'views/templates/admin/panel.tpl');
    }

    public function save($configs)
    {
        if ($errors = $this->validateSettings($configs)) {
            return $errors;
        }
        return $this->updateSettings($configs);
    }

    private function validateSettings($configs)
    {
        $errors = array();
        if (Tools::isEmpty($configs['JXSECURITY_LOGINFAIL_BLOCK']) || !Validate::isInt($configs['JXSECURITY_LOGINFAIL_BLOCK']) || $configs['JXSECURITY_LOGINFAIL_BLOCK'] < 0) {
            $errors[] = $this->l('"Maximum number of attempts before blocking" is invalid. Only positive integer value is acceptable.');
        }
        if (Tools::isEmpty($configs['JXSECURITY_LOGINFAIL_DISABLE']) || !Validate::isInt($configs['JXSECURITY_LOGINFAIL_DISABLE']) || $configs['JXSECURITY_LOGINFAIL_DISABLE'] < 0) {
            $errors[] = $this->l('"Maximum number of attempts before disconnecting" is invalid. Only positive integer value is acceptable.');
        }
        if (Tools::isEmpty($configs['JXSECURITY_LOGINFAIL_MESSAGE']) || !Validate::isInt($configs['JXSECURITY_LOGINFAIL_MESSAGE']) || $configs['JXSECURITY_LOGINFAIL_MESSAGE'] < 0) {
            $errors[] = $this->l('"Maximum number of attempts before sending a message to the administrator" is invalid. Only positive integer value is acceptable.');
        }

        return $errors;
    }

    private function getCustomersOnline()
    {
        if ($maintenance_ips = Configuration::get('PS_MAINTENANCE_IP')) {
            $maintenance_ips = implode(',', array_map('ip2long', array_map('trim', explode(',', $maintenance_ips))));
        }

        if (Configuration::get('PS_STATSDATA_CUSTOMER_PAGESVIEWS')) {
            $sql = 'SELECT u.id_customer, u.firstname, u.lastname, c.ip_address, u.email, u.active, pt.name as page
					FROM `'._DB_PREFIX_.'connections` c
					LEFT JOIN `'._DB_PREFIX_.'connections_page` cp ON c.id_connections = cp.id_connections
					LEFT JOIN `'._DB_PREFIX_.'page` p ON p.id_page = cp.id_page
					LEFT JOIN `'._DB_PREFIX_.'page_type` pt ON p.id_page_type = pt.id_page_type
					INNER JOIN `'._DB_PREFIX_.'guest` g ON c.id_guest = g.id_guest
					INNER JOIN `'._DB_PREFIX_.'customer` u ON u.id_customer = g.id_customer
					WHERE cp.`time_end` IS NULL
						'.Shop::addSqlRestriction(false, 'c').'
						AND TIME_TO_SEC(TIMEDIFF(\''.pSQL(date('Y-m-d H:i:00', time())).'\', cp.`time_start`)) < 900
					'.($maintenance_ips ? 'AND c.ip_address NOT IN ('.pSQL(preg_replace('/[^,0-9]/', '', $maintenance_ips)).')' : '').'
					AND u.`active` = 1
					GROUP BY u.id_customer
					ORDER BY u.firstname, u.lastname';
        } else {
            $sql = 'SELECT u.id_customer, u.firstname, c.ip_address, u.lastname, u.email, u.active,  "-" as page
					FROM `'._DB_PREFIX_.'connections` c
					INNER JOIN `'._DB_PREFIX_.'guest` g ON c.id_guest = g.id_guest
					INNER JOIN `'._DB_PREFIX_.'customer` u ON u.id_customer = g.id_customer
					WHERE TIME_TO_SEC(TIMEDIFF(\''.pSQL(date('Y-m-d H:i:00', time())).'\', c.`date_add`)) < 900
						'.Shop::addSqlRestriction(false, 'c').'
					'.($maintenance_ips ? 'AND c.ip_address NOT IN ('.pSQL(preg_replace('/[^,0-9]/', '', $maintenance_ips)).')' : '').'
					AND u.`active` = 1
					GROUP BY u.id_customer
					ORDER BY u.firstname, u.lastname';
        }
        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        return array($results, Db::getInstance()->NumRows());
    }

    private function getVisitorsOnline()
    {
        if ($maintenance_ips = Configuration::get('PS_MAINTENANCE_IP')) {
            $maintenance_ips = implode(',', array_map('ip2long', array_filter(array_map('trim', explode(',', $maintenance_ips)))));
        }

        if (Configuration::get('PS_STATSDATA_CUSTOMER_PAGESVIEWS')) {
            $sql = 'SELECT c.id_guest, c.ip_address, c.date_add, c.http_referer, pt.name as page
					FROM `'._DB_PREFIX_.'connections` c
					LEFT JOIN `'._DB_PREFIX_.'connections_page` cp ON c.id_connections = cp.id_connections
					LEFT JOIN `'._DB_PREFIX_.'page` p ON p.id_page = cp.id_page
					LEFT JOIN `'._DB_PREFIX_.'page_type` pt ON p.id_page_type = pt.id_page_type
					INNER JOIN `'._DB_PREFIX_.'guest` g ON c.id_guest = g.id_guest
					WHERE (g.id_customer IS NULL OR g.id_customer = 0)
						'.Shop::addSqlRestriction(false, 'c').'
						AND cp.`time_end` IS NULL
					AND TIME_TO_SEC(TIMEDIFF(\''.pSQL(date('Y-m-d H:i:00', time())).'\', cp.`time_start`)) < 900
					'.($maintenance_ips ? 'AND c.ip_address NOT IN ('.pSQL(preg_replace('/[^,0-9]/', '', $maintenance_ips)).')' : '').'
					GROUP BY c.id_connections
					ORDER BY c.date_add DESC';
        } else {
            $sql = 'SELECT c.id_guest, c.ip_address, c.date_add, c.http_referer, "-" as page
					FROM `'._DB_PREFIX_.'connections` c
					INNER JOIN `'._DB_PREFIX_.'guest` g ON c.id_guest = g.id_guest
					WHERE (g.id_customer IS NULL OR g.id_customer = 0)
						'.Shop::addSqlRestriction(false, 'c').'
						AND TIME_TO_SEC(TIMEDIFF(\''.pSQL(date('Y-m-d H:i:00', time())).'\', c.`date_add`)) < 900
					'.($maintenance_ips ? 'AND c.ip_address NOT IN ('.pSQL(preg_replace('/[^,0-9]/', '', $maintenance_ips)).')' : '').'
					ORDER BY c.date_add DESC';
        }

        $results = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        return array($results, Db::getInstance()->NumRows());
    }

    public function getGuestIp($id_guest)
    {
        if (!$id_guest) {
            return false;
        }
        $query = "SELECT ip_address 
                 FROM `"._DB_PREFIX_."connections`
                 WHERE `id_guest` = {$id_guest}";

        $ips = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($query)[0];

        return $ips['ip_address'];
    }

    public function updateHtaccess()
    {
        $ips = JxSecurityPanelBlacklist::getItems();

        $string = '';
        if ($ips) {
            foreach ($ips as $ip) {
                $string .= long2ip($ip['ip_address']).',';
            }

            $ips = $this->parseIps($string);
        }

        $this->writeHtaccess($ips);
    }

    public function writeHtaccess($ips)
    {
        $this->removeHtaccess();
        if (!$ips) {
            return true;
        }
        $source = "\n# start ~ module blocklist section\nOrder Deny,Allow\nDeny from {$ips}\n# end ~ module blocklist section\n";

        $path = _PS_ROOT_DIR_.'/.htaccess';
        file_put_contents($path, $source, FILE_APPEND);
    }

    public function removeHtaccess()
    {
        $key1 = "\n# start ~ module blocklist section";
        $key2 = "# end ~ module blocklist section\n";
        $path = _PS_ROOT_DIR_.'/.htaccess';
        if (file_exists($path) && is_writable($path)) {
            $s = Tools::file_get_contents($path);
            $p1 = strpos($s, $key1);
            $p2 = strpos($s, $key2, $p1);
            if ($p1 === false || $p2 === false) {
                return false;
            }
            $s = Tools::substr($s, 0, $p1).Tools::substr($s, $p2 + Tools::strlen($key2));
            file_put_contents($path, $s);
        }

        return true;
    }

    public function parseIps($string)
    {
        $ips = '';
        $data = str_replace(' ', '', $string);
        $data = explode(',', $data);
        foreach ($data as $value) {
            $ips .= " {$this->validateIpsDiapason($value)}";
        }

        return $ips;
    }

    public function validateIpsDiapason($string)
    {
        $ips = explode('-', $string);

        if (count($ips) !== 2) {
            return $string;
        }

        if ((int)str_replace('.', '', $ips[0]) > (int)str_replace('.', '', $ips[1])) {
            return "";
        }

        return implode(" ", CIDR::rangeToCIDRList($ips[0], $ips[1]));
    }

    public function getLoginFail()
    {
        $items = JxSecurityPanelLoginFail::getItems();

        return $items;
    }

    public function getBlacklist()
    {
        $items = JxSecurityPanelBlacklist::getItems();

        return $items;
    }

    public function getBanlist()
    {
        $query = 'SELECT *
                FROM `'._DB_PREFIX_.'customer`
                WHERE `active` = 0';

        if (!$list = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($query)) {
            return array();
        }

        return $list;
    }

    public function renderTab()
    {
        $this->context->smarty->assign(array(
            'configs' => $this->getSettings($this->getDefaultSettings()),
            'uri' => $this->context->link->getAdminLink($this->ajax_controller),
            'customers' => $this->getCustomersOnline(),
            'visitors' => $this->getVisitorsOnline(),
            'login_fail' => $this->getLoginFail(),
            'blacklist' => $this->getBlacklist(),
            'banlist' => $this->getBanlist()
        ));
        return $this->context->smarty->fetch($this->local_path.'views/templates/admin/tab.tpl');
    }

    public function renderSubTab($tab)
    {
        $this->context->smarty->assign(array(
            'configs' => $this->getSettings($this->getDefaultSettings()),
            'uri' => $this->context->link->getAdminLink($this->ajax_controller),
            'customers' => $this->getCustomersOnline(),
            'visitors' => $this->getVisitorsOnline(),
            'login_fail' => $this->getLoginFail(),
            'blacklist' => $this->getBlacklist(),
            'banlist' => $this->getBanlist()
        ));

        return $this->context->smarty->fetch("{$this->local_path}views/templates/admin/sub_tab/{$tab}.tpl");
    }

    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJquery();
            $this->context->controller->addJS($this->_path.'views/js/jxsecurityuser_admin.js');
            $this->context->controller->addCSS($this->_path.'views/css/jxsecurityuser_admin.css');
        }
    }

    public function banCustomer($id_customer)
    {
        $customer = new Customer($id_customer);
        $customer->active = false;

        $customer->save();
    }

    public function unbanCustomer($id_customer)
    {
        $customer = new Customer($id_customer);
        $customer->active = true;

        $customer->save();
    }

    public function blockIpAddress($ip_address)
    {
        $item = JxSecurityPanelBlacklist::getItems($ip_address);
        if (!count($item)) {
            $item = new JxSecurityPanelBlacklist();
            $item->ip_address = $ip_address;
            $item->save();
        }

        $this->updateHtaccess();

        return true;
    }

    public function unblockIpAddress($ip_address)
    {
        $item = JxSecurityPanelBlacklist::getItems($ip_address);
        if (count($item)) {
            $item = new JxSecurityPanelBlacklist($item[0]['id']);
            if ($loginFail = JxSecurityPanelLoginFail::getItems($ip_address)) {
                $ipFailed = new JxSecurityPanelLoginFail($loginFail[0]['id']);
                $ipFailed->attempt = 0;
                $ipFailed->update();
            }
            $item->delete();
            $this->updateHtaccess();
        }

        return true;
    }

    protected function validateLogin()
    {
        $customer = new Customer();
        $authentication = $customer->getByEmail(
            Tools::getValue('email'),
            Tools::getValue('password')
        );

        if (!$authentication || !$customer->id || $customer->is_guest) {
            return false;
        }

        return true;
    }

    protected function addLoginFail()
    {
        $ip_address = $this->getGuestIp($this->context->customer->id_guest);
        $item = JxSecurityPanelLoginFail::getItems($ip_address);

        if (count($item)) {
            $item = new JxSecurityPanelLoginFail($item[0]['id']);
        } else {
            $item = new JxSecurityPanelLoginFail();
        }

        $item->ip_address = $ip_address;
        $item->date_upd = date("Y-m-d H:i:s");
        $item->attempt++;
        $item->save();

        return $item;
    }

    protected function sendEmail($item)
    {
        $dir = (file_exists(dirname(__FILE__).'/mails/'.$this->context->language->iso_code.'/notification.txt')
            && file_exists(dirname(__FILE__).'/mails/'.$this->context->language->iso_code.'/notification.html')) ? dirname(__FILE__).'/mails/' : false;
        Mail::Send(
            $this->context->language->id,
            'notification',
            $this->l('Login attempts notification'),
            array(
                '{ip_address}' => long2ip($item->ip_address),
                '{attempts}' => $item->attempt
            ),
            Configuration::get('PS_SHOP_EMAIL'),
            null,
            Configuration::get('PS_SHOP_EMAIL'),
            Configuration::get('PS_SHOP_NAME'),
            null,
            null,
            $dir,
            null,
            $this->context->shop->id
        );
    }

    protected function checkAttempts($item)
    {
        $block = Configuration::get('JXSECURITY_LOGINFAIL_BLOCK');
        $message = Configuration::get('JXSECURITY_LOGINFAIL_MESSAGE');

        if ((bool)$block && $block <= $item->attempt) {
            $this->blockIpAddress($item->ip_address);
        }

        if ((bool)$message && $message <= $item->attempt) {
            $this->sendEmail($item);
        }
    }

    public function hookActionAuthenticationBefore($params)
    {
        if (!$this->validateLogin()) {
            $item = $this->addLoginFail();
            $this->checkAttempts($item);
        }
    }

    public function hookDisplayHeader()
    {
        $ip_address = $this->getGuestIp($this->context->customer->id_guest);
        $item = JxSecurityPanelLoginFail::getItems($ip_address);

        if (count($item)) {
            $item = new JxSecurityPanelLoginFail($item[0]['id']);
        } else {
            $item = new JxSecurityPanelLoginFail();
        }

        $this->checkAttempts($item);
    }

    public function hookDisplayCustomerLoginFormAfter()
    {
        $ip_address = $this->getGuestIp($this->context->customer->id_guest);
        $login_fail = JxSecurityPanelLoginFail::getItems($ip_address);
        $this->context->smarty->assign(array(
            'configs' => $this->getSettings($this->getDefaultSettings()),
            'login_fail' => $login_fail
        ));

        return $this->context->smarty->fetch("{$this->local_path}views/templates/hook/displayCustomerLoginFormAfter.tpl");
    }
}
