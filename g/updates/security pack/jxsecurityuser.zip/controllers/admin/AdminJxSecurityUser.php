<?php
/**
 * 2017-2018 Zemez
 *
 * JX Security User
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 *  @author    Zemez
 *  @copyright 2017-2018 Zemez
 *  @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */

include_once _PS_MODULE_DIR_ . 'jxsecurityuser/jxsecurityuser.php';

class AdminJxSecurityUserController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->module = new Jxsecurityuser();
    }

    public function ajaxProcessSaveSettings()
    {
        $result = $this->module->save(Tools::getValue('configs'));
        if ($result !== true) {
            die(json_encode(array('status' => 'false', 'errors' => implode("\r\n", $result))));
        }

        die(json_encode(array('status' => 'true','message' => $this->module->l('Settings successfully saved!'))));
    }

    public function ajaxProcessBanCustomer()
    {
        $this->module->banCustomer(Tools::getValue('id_customer'));

        die(json_encode(array('status' => 'true', 'message' => $this->module->l('Customer successfully banned!'))));
    }

    public function ajaxProcessUnbanCustomer()
    {
        $this->module->unbanCustomer(Tools::getValue('id_customer'));

        die(json_encode(array('status' => 'true', 'message' => $this->module->l('Customer successfully unbanned!'))));
    }


    public function ajaxProcessBlockIpAddress()
    {
        $this->module->blockIpAddress(Tools::getValue('ip_address'));

        die(json_encode(array('status' => 'true', 'message' => $this->module->l('Ip successfully blocked!'))));
    }

    public function ajaxProcessUnblockIpAddress()
    {
        $this->module->unBlockIpAddress(Tools::getValue('ip_address'));

        die(json_encode(array('status' => 'true', 'message' => $this->module->l('Ip successfully blocked!'))));
    }

    public function ajaxProcessLoadTab()
    {
        $tab = Tools::getValue('sub_tab');

        die(json_encode(array('status' => 'true', 'content' => $this->module->renderSubTab($tab))));
    }
}
