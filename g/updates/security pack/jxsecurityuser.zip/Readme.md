# JX Security Panel

v 1.0.2
FIX:
 - admin fields validation is improved

v 1.0.1
FIX:
 - fixed jxsecuritypanel tab verification