<?php
/**
 * 2017-2018 Zemez
 *
 * JX Security Watermark
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 *  @author    Zemez
 *  @copyright 2017-2018 Zemez
 *  @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class Jxsecuritywatermark extends Module
{
    protected $id_shop;
    protected $htaccess;
    protected $watermark;
    protected $imageTypes;
    public $errors = array();
    public $ajax_controller = 'AdminJxSecurityWatermark';

    public function __construct()
    {
        $this->name = 'jxsecuritywatermark';
        $this->tab = 'administration';
        $this->version = '1.0.2';
        $this->author = 'Zemez';
        $this->need_instance = 1;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('JX Security WaterMark');
        $this->description = $this->l('Security module for your shop.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall my module?');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);

        $this->htaccess = _PS_ROOT_DIR_ . '/.htaccess';
        $this->id_shop = $this->context->shop->id;
        $this->watermark = $this->getWatermarkImage();

        $types = json_decode(Configuration::get('JXSECURITY_WATERMARK_TYPES'));

        foreach (ImageType::getImagesTypes('products') as $type) {
            if (is_null($types) || in_array($type['id_image_type'], $types)) {
                $this->imageTypes[] = $type;
            }
        }
    }

    public function install()
    {
        if ($this->checkTableExists()) {
            include(dirname(__FILE__) . '/sql/install.php');
        }
        $this->writeHtaccess();

        return parent::install() &&
            $this->installTab() &&
            $this->updateSettings($this->getDefaultSettings()) &&
            $this->registerHook('watermark') &&
            $this->registerHook('backOfficeHeader');
    }

    public function uninstall()
    {
        if ($this->checkTableExists()) {
            include(dirname(__FILE__) . '/sql/uninstall.php');
        }

        $this->removeHtaccess();

        return parent::uninstall() &&
            $this->uninstallTab() &&
            $this->deleteSettings($this->getDefaultSettings());
    }

    protected function installTab()
    {
        $tab = new Tab();

        $this->active = 1;
        $langs = Language::getLanguages(false);
        if (is_array($langs)) {
            foreach ($langs as $lang) {
                $tab->name[$lang['id_lang']] = 'jxsecuritywatermark';
            }
        }

        $tab->class_name = 'AdminJxSecurityWatermark';
        $tab->module = $this->name;
        $tab->id_parent = -1;

        return (bool)$tab->add();
    }

    protected function uninstallTab()
    {
        if ($id = (int)Tab::getIdFromClassName('AdminJxSecurityWatermark')) {
            $tab = new Tab($id);
            $tab->delete();
        }

        return true;
    }

    protected function checkTableExists()
    {
        $tables = Db::getInstance()->executeS("SHOW TABLES");

        if (is_array($tables)) {
            foreach ($tables as $table) {
                if (in_array(_DB_PREFIX_.'jxsecuritypanel', $table)) {
                    return true;
                }
            }
        }

        return false;
    }

    public function getDefaultSettings()
    {
        return array(
            'JXSECURITY_WATERMARK_OPACITY' => 60,
            'JXSECURITY_WATERMARK_X' => 'left',
            'JXSECURITY_WATERMARK_Y' => 'top',
            'JXSECURITY_WATERMARK_IMAGES' => '',
            'JXSECURITY_WATERMARK_TYPES' => '',
            'WATERMARK_LOGGED' => false,
        );
    }

    public function getSettings($configs)
    {
        foreach (array_keys($configs) as $key) {
            $configs[$key] = Configuration::get($key);
        }

        return $configs;
    }

    public function updateSettings($configs)
    {
        foreach ($configs as $key => $value) {
            if (is_array($value)) {
                $value = json_encode($value);
            }

            Configuration::updateValue($key, $value);
        }

        return true;
    }

    public function deleteSettings($configs)
    {
        foreach (array_keys($configs) as $value) {
            Configuration::deleteByName($value);
        }

        return true;
    }

    public function validateSettings($settings)
    {
        $this->validateOpacity($settings['JXSECURITY_WATERMARK_OPACITY']);
    }

    public function validateOpacity($value)
    {
        if ($value === '') {
            $this->errors[] = $this->l('Opacity can\'t be empty');
        } elseif (!Validate::isInt($value)) {
            $this->errors[] = $this->l('Opacity must be integer type');
        } elseif ($value < 1 || $value > 100) {
            $this->errors[] = $this->l('Opacity must be from 1 to 100 value');
        }
    }

    public function getWatermarkImage()
    {
        $watermark = array(
            'realpath' => dirname(__FILE__) . "/views/img/watermark-{$this->id_shop}.gif",
            'uri' => "../modules/{$this->name}/views/img/watermark-{$this->id_shop}.gif?t=".rand(0, time())
        );

        if (!file_exists($watermark['realpath'])) {
            $watermark = array(
                'realpath' => dirname(__FILE__) . "/views/img/watermark.gif",
                'uri' => "../modules/{$this->name}/views/img/watermark.gif?t=".rand(0, time())
            );
        }

        return $watermark;
    }

    public function uploadWatermark($image)
    {
        if (isset($image) && !empty($image['tmp_name'])) {
            if (!ImageManager::isRealImage($image['tmp_name'], $image['type'], array('image/gif'))) {
                return $this->errors[] = $this->l('Image must be in GIF format.');
            }
            /* Check watermark validity */
            if ($error = ImageManager::validateUpload($image)) {
                $this->errors[] = $error;
            } elseif (!copy($image['tmp_name'], dirname(__FILE__)."/views/img/watermark-{$this->id_shop}.gif")) {
                $this->errors[] = sprintf($this->l('An error occurred while uploading watermark: %1$s to %2$s'), $image['tmp_name'], dirname(__FILE__)."/views/img/watermark-{$this->id_shop}.gif");
            }
        }
    }

    public function getAdminDir()
    {
        $admin_dir = str_replace('\\', '/', _PS_ADMIN_DIR_);
        $admin_dir = explode('/', $admin_dir);
        $len = count($admin_dir);

        return $len > 1 ? $admin_dir[$len - 1] : _PS_ADMIN_DIR_;
    }

    public function writeHtaccess()
    {
        $this->removeHtaccess();
        $content = "\n# start ~ module jxsecuritywatermark
<IfModule mod_rewrite.c>
    Options +FollowSymLinks
    RewriteEngine On
    RewriteCond expr \"! %{HTTP_REFERER} -strmatch '*://%{HTTP_HOST}*/{$this->getAdminDir()}/*'\"
    RewriteRule [0-9/]+/[0-9]+\\.jpg$ - [F]
</IfModule>
# end ~ module jxsecuritywatermark\n";

        file_put_contents($this->htaccess, $content, FILE_APPEND);
    }

    public function removeHtaccess()
    {
        $start_comment = "\n# start ~ module jxsecuritywatermark";
        $end_comment = "# end ~ module jxsecuritywatermark\n";

        if (file_exists($this->htaccess) && is_writable($this->htaccess)) {
            $content = Tools::file_get_contents($this->htaccess);
            $start = strpos($content, $start_comment);
            $end = strpos($content, $end_comment, $start);

            if ($start === false || $end === false) {
                return false;
            }

            $content = Tools::substr($content, 0, $start) . Tools::substr($content, $end + Tools::strlen($end_comment));
            file_put_contents($this->htaccess, $content);
        }

        return true;
    }

    public function hookActionWatermark($params)
    {
        $image = new Image($params['id_image']);
        $image->id_product = $params['id_product'];
        $file = _PS_PROD_IMG_DIR_.$image->getExistingImgPath().'-watermark.jpg';
        $file_org = _PS_PROD_IMG_DIR_.$image->getExistingImgPath().'.jpg';

        //first make a watermark image
        $return = $this->watermarkByImage(_PS_PROD_IMG_DIR_.$image->getExistingImgPath().'.jpg', $this->watermark['realpath'], $file);

        if (!Configuration::get('WATERMARK_HASH')) {
            Configuration::updateValue('WATERMARK_HASH', Tools::passwdGen(10));
        }

        if (isset($params['image_type']) && is_array($params['image_type'])) {
            $this->imageTypes = array_intersect($this->imageTypes, $params['image_type']);
        }

        //go through file formats defined for watermark and resize them
        foreach ($this->imageTypes as $imageType) {
            $newFile = _PS_PROD_IMG_DIR_.$image->getExistingImgPath().'-'.Tools::stripslashes($imageType['name']).'.jpg';
            if (!ImageManager::resize($file, $newFile, (int)$imageType['width'], (int)$imageType['height'])) {
                $return = false;
            }

            $new_file_org = _PS_PROD_IMG_DIR_.$image->getExistingImgPath().'-'.Tools::stripslashes($imageType['name']).'-'.Configuration::get('WATERMARK_HASH').'.jpg';
            if (!ImageManager::resize($file_org, $new_file_org, (int)$imageType['width'], (int)$imageType['height'])) {
                $return = false;
            }
        }

        return $return;
    }

    private function watermarkByImage($imagepath, $watermarkpath, $outputpath)
    {
        $Xoffset = $Yoffset = $xpos = $ypos = 0;

        list($tmp_width, $tmp_height, $type) = getimagesize($imagepath);
        $image = ImageManager::create($type, $imagepath);
        if (!$image) {
            return false;
        }
        if (!$imagew = imagecreatefromgif($watermarkpath)) {
            die($this->l('The watermark image is not a real GIF, please CONVERT the image.'));
        }
        list($watermarkWidth, $watermarkHeight) = getimagesize($watermarkpath);
        list($imageWidth, $imageHeight) = getimagesize($imagepath);
        $configs = $this->getSettings($this->getDefaultSettings());
        if ($configs['JXSECURITY_WATERMARK_X'] == 'middle') {
            $xpos = $imageWidth / 2 - $watermarkWidth / 2 + $Xoffset;
        }
        if ($configs['JXSECURITY_WATERMARK_X'] == 'left') {
            $xpos = 0 + $Xoffset;
        }
        if ($configs['JXSECURITY_WATERMARK_X'] == 'right') {
            $xpos = $imageWidth - $watermarkWidth - $Xoffset;
        }
        if ($configs['JXSECURITY_WATERMARK_Y'] == 'middle') {
            $ypos = $imageHeight / 2 - $watermarkHeight / 2 + $Yoffset;
        }
        if ($configs['JXSECURITY_WATERMARK_Y'] == 'top') {
            $ypos = 0 + $Yoffset;
        }
        if ($configs['JXSECURITY_WATERMARK_Y'] == 'bottom') {
            $ypos = $imageHeight - $watermarkHeight - $Yoffset;
        }
        if (!imagecopymerge($image, $imagew, $xpos, $ypos, 0, 0, $watermarkWidth, $watermarkHeight, $configs['JXSECURITY_WATERMARK_OPACITY'])) {
            return false;
        }

        switch ($type) {
            case IMAGETYPE_PNG:
                $type = 'png';
                break;
            case IMAGETYPE_GIF:
                $type = 'gif';
                break;
            case IMAGETYPE_JPEG:
                $type = 'jpg';
                break;
        }

        imagealphablending($image, false);
        imagesavealpha($image, true);

        return ImageManager::write($type, $image, $outputpath);
    }

    public function getContent()
    {
        $this->context->smarty->assign(array(
            'configs' => $this->getSettings($this->getDefaultSettings()),
            'uri' => $this->context->link->getAdminLink($this->ajax_controller),
            'types' => ImageType::getImagesTypes('products'),
            'panel' => true,
            'watermark' => $this->watermark,
            'link' => new Link()
        ));
        return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/panel.tpl');
    }

    public function renderTab()
    {
        $this->context->smarty->assign(array(
            'configs' => $this->getSettings($this->getDefaultSettings()),
            'uri' => $this->context->link->getAdminLink($this->ajax_controller),
            'panel' => false,
            'watermark' => $this->watermark,
            'types' => ImageType::getImagesTypes('products'),
            'link' => new Link()
        ));
        return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/tab.tpl');
    }

    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addCSS($this->_path . 'views/css/jxsecuritypanel_admin.css');
        }
    }
}
