# JX Security Watermark

v 1.0.2
FIX:
 - fixed a typo which causes an error during settings savings

v 1.0.1
FIX:
 - fixed jxsecuritypanel tab verification

