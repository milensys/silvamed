# JX Mega Layout

v 1.5.5
FIX:
- added temporary workaround for address_token variable which is bad defined in PS 1.7.6.2

v 1.5.4
FIX:
- fixed cancel buttons duplication in extra-content forms (BO)
- fixed color picker icons and backgrounds (BO)
- fixed an issue with extra-content video preview if a video isn't added yet (BO)
- improved verification of layouts archives before import (BO)

v 1.5.3
FIX: fixed an issue with extra-content when one of the available languages is't active

v 1.5.2
FIX: fixed an issue when admin panel active layout has no inner items

v 1.5.1
FIX: added a condition to check if a module exists before add it to an admin part. Needed because some issues started to appear in some servers

v 1.4.1
FIX: added check if a JX Blog module is installed and enabled to post.tpl file which is responding for custom content posts displaying.

v 1.4.0
UPD: added opportunities to import/export extra content

v 1.3.3
FIX: fixed an issue with extra-content sorting

v 1.3.2
UPD: added hook name to module front blocks

v 1.3.1
FIX: small fixes with front-end columns' classes