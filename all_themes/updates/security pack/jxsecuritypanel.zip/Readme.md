# JX Security Panel

v 1.0.1
FIX:
 - fixed an error during the module installation
 - fixed an error with jQuery including in the admin panel