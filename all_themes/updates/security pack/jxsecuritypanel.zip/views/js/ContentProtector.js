/**
 * 2017-2018 Zemez
 *
 * JX Security Panel
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 *  @author    Zemez
 *  @copyright 2017-2018 Zemez
 *  @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */
"use strict";

class ContentProtector {
  constructor(settings) {
    this._defaults = {
      hotKeys: {
        //copy
        "ctrl+67": "copy",
        "ctrl+45": "copy",
        //select
        "ctrl+65": "select",
        //search
        "ctrl+70": "search",
        "114": "search",
        //save
        "ctrl+83": "save",
        //paste
        "ctrl+86": "paste",
        //cut
        "ctrl+88": "cut",
        //print
        "ctrl+80": "print",
        //help
        "ctrl+112": "help",
        //dev tools
        "shift+118": "dev_tools",
        "ctrl+shift+67": "dev_tools",
        "ctrl+shift+73": "dev_tools",
        "123": "dev_tools",
        //source code
        "ctrl+85": "source_code",
        //reload
        "116": "reload",
        "ctrl+82": "reload",
        //reload cache
        "ctrl+116": "reload_cache",
        "ctrl+shift+82": "reload_cache",
        //menu
        "alt+69": "menu",
        "alt+70": "menu",
        "122": "menu",
        //quit
        "ctrl+81": "quit",
        "ctrl+shift+81": "quit",
        //close tab
        "ctrl+115": "close_tab"
      },
      dragndrop: false,
      mouseSelect: false,
      contextmenu: false,
    };
    this.settings = Object.assign({}, this._defaults, settings || {});
  }

  _reject(event) {
    event.preventDefault();
    event.stopImmediatePropagation();

    return false;
  }

  _keydown(keys, event) {
    !this.settings[this.settings.hotKeys[keys]] || this._reject(event);
  }

  _dragndrop(event) {
    !this.settings.dragndrop || this._reject(event);
  }

  _select(target) {
    if (typeof target.onselectstart !== 'undefined') {
      target.onselectstart = () => {
        return false;
      };
    } else if (typeof target.style.MozUserSelect !== 'undefined') {
      target.style.MozUserSelect = 'none';
    } else {
      target.onmousedown = event => {
        if (event && event.target && event.target.tagName && /^(input|select)$/i.test(e.target.tagName)) {
          return true;
        }
        return false;
      };
    }

    target.style.cursore = 'default';
  }

  _contextmenu(event) {
    !this.settings.contextmenu || this._reject(event);
  }

  _contextmenuMobile(event) {
    if ('ontouchstart' in window || navigator.maxTouchPoints) {
      this._reject(event);
    }
  }

  _generateKeysCombination(e) {
    let ctrlKey = e.ctrlKey ? "ctrl+" : "",
      shiftKey = e.shiftKey ? "shift+" : "",
      altKey = e.altKey ? "alt+" : "";
    return ctrlKey + shiftKey + altKey + e.keyCode;
  }

  init() {
    document.addEventListener('keydown', event => {
      this._keydown(this._generateKeysCombination(event), event);
    });
    document.addEventListener('dragstart', event => {
      this._dragndrop(event);
    });
    document.addEventListener('contextmenu', event => {
      this._contextmenu(event);
    });

    window.oncontextmenu = event => {
      !this.settings.contextmenuMobile || this._contextmenuMobile(event);
    };

    !this.settings.mouseSelect || this._select(document.body);
  }
}