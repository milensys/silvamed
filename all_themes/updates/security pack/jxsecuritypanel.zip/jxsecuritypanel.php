<?php
/**
 * 2017-2018 Zemez
 *
 * JX Security Panel
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 *  @author    Zemez
 *  @copyright 2017-2018 Zemez
 *  @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

include_once _PS_MODULE_DIR_ . 'jxsecuritypanel/classes/JxSecurityPanelTabs.php';

class Jxsecuritypanel extends Module
{
    public function __construct()
    {
        $this->name = 'jxsecuritypanel';
        $this->tab = 'administration';
        $this->version = '1.0.1';
        $this->author = 'Zemez';
        $this->need_instance = 1;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('JX Security Panel');
        $this->description = $this->l('Security module for your shop.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall my module?');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->ajax_controller = 'AdminJxSecurity';
        $this->htaccess = _PS_ROOT_DIR_ . '/.htaccess';
    }

    public function install()
    {
        include(dirname(__FILE__) . '/sql/install.php');

        return parent::install() &&
            $this->installTab() &&
            $this->updateSettings($this->getDefaultSettings()) &&
            $this->registerHook('header') &&
            $this->registerHook('backOfficeHeader');
    }

    public function uninstall()
    {
        include(dirname(__FILE__).'/sql/uninstall.php');
        $this->removeHtaccess();

        return parent::uninstall() &&
            $this->uninstallTab();
    }

    protected function installTab()
    {
        $tab = new Tab();
        $this->active = 1;
        $langs = Language::getLanguages(false);
        if (is_array($langs)) {
            foreach ($langs as $lang) {
                $tab->name[$lang['id_lang']] = 'jxsecuritypanel';
            }
        }
        $tab->class_name = 'AdminJxSecurity';
        $tab->module = $this->name;
        $tab->id_parent = -1;

        return (bool)$tab->add();
    }

    protected function uninstallTab()
    {
        if ($id = (int)Tab::getIdFromClassName('AdminJxSecurity')) {
            $tab = new Tab($id);
            $tab->delete();
        }

        return true;
    }

    public function getDefaultSettings()
    {
        return array(
            'JXSECURITY_CONTENT_COPY'          => false,
            'JXSECURITY_CONTENT_PASTE'         => false,
            'JXSECURITY_CONTENT_CUT'           => false,
            'JXSECURITY_CONTENT_SELECT'        => false,
            'JXSECURITY_CONTENT_SEARCH'        => false,
            'JXSECURITY_CONTENT_SAVE'          => false,
            'JXSECURITY_CONTENT_PRINT'         => false,
            'JXSECURITY_CONTENT_HELP'          => false,
            'JXSECURITY_CONTENT_DEV'           => false,
            'JXSECURITY_CONTENT_SOURCE'        => false,
            'JXSECURITY_CONTENT_RELOAD'        => false,
            'JXSECURITY_CONTENT_RELOAD_CACHE'  => false,
            'JXSECURITY_CONTENT_SCREEN'        => false,
            'JXSECURITY_CONTENT_CONTEXTMENU'   => false,
            'JXSECURITY_CONTENT_HOTLINKING'    => false,
            'JXSECURITY_CONTENT_TEXTSELECTION' => false,
            'JXSECURITY_CONTENT_DRAGNDROP'     => false,
            'JXSECURITY_CONTENT_COPY_TEXT'     => array()
        );
    }

    public function getSettings($configs)
    {
        foreach (array_keys($configs) as $key) {
            if ($key == 'JXSECURITY_CONTENT_COPY_TEXT') {
                foreach (Language::getLanguages() as $language) {
                    $configs[$key][$language['id_lang']] = Configuration::get($key, $language['id_lang']);
                }
            } else {
                $configs[$key] = Configuration::get($key);
            }
        }

        return $configs;
    }

    public function updateSettings($configs)
    {
        foreach ($configs as $key => $value) {
            Configuration::updateValue($key, $value);
        }

        return true;
    }

    public function deleteSettings($configs)
    {
        foreach (array_keys($configs) as $value) {
            Configuration::deleteByName($value);
        }

        return true;
    }

    protected function setMedia()
    {
        $configs = $this->getSettings($this->getDefaultSettings());
        Media::addJsDef($configs);
    }

    public function getContent()
    {
        $this->context->smarty->assign(
            array(
                'tabs' => $this->getTabs(),
            )
        );

        return $this->context->smarty->fetch($this->local_path.'views/templates/admin/panel.tpl');
    }

    public function renderTab()
    {
        $this->context->smarty->assign(
            array(
                'configs'             => $this->getSettings($this->getDefaultSettings()),
                'uri'                 => $this->context->link->getAdminLink($this->ajax_controller),
                'languages'           => Language::getLanguages(),
                'defaultFormLanguage' => $this->context->language->id
            )
        );

        return $this->context->smarty->fetch($this->local_path.'views/templates/admin/jxsecuritycontent/tab.tpl');
    }

    public function getTabs()
    {
        $tabs = JxSecurityPanelTabs::get();
        foreach ($tabs as $key => $tab) {
            $module = Module::getInstanceByName($tab['module']);
            $tabs[$key]['content'] = $module->renderTab();
        }

        return $tabs;
    }

    public function writeHtaccess()
    {
        $this->removeHtaccess();
        $content = "\n# start ~ module jxsecuritycontent
RewriteEngine on
RewriteCond %{HTTP_REFERER} !^$
RewriteCond %{HTTP_REFERER} !^http(s)?://(www\.)?{$this->context->shop->domain} [NC]
RewriteRule \.(gif|jpg|jpeg|png)$ - [F]
# end ~ module jxsecuritycontent\n";

        file_put_contents($this->htaccess, $content, FILE_APPEND);
    }

    public function removeHtaccess()
    {
        $start_comment = "\n# start ~ module jxsecuritycontent";
        $end_comment = "# end ~ module jxsecuritycontent\n";

        if (file_exists($this->htaccess) && is_writable($this->htaccess)) {
            $content = Tools::file_get_contents($this->htaccess);
            $start = strpos($content, $start_comment);
            $end = strpos($content, $end_comment, $start);

            if ($start === false || $end === false) {
                return false;
            }

            $content = Tools::substr($content, 0, $start) . Tools::substr($content, $end + Tools::strlen($end_comment));
            file_put_contents($this->htaccess, $content);
        }

        return true;
    }

    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('configure') == $this->name) {
            $this->context->controller->addJquery();
            $this->context->controller->addJS($this->_path.'views/js/jxsecuritypanel_admin.js');
            $this->context->controller->addCSS($this->_path.'views/css/jxsecuritypanel_admin.css');
        }
    }

    public function hookHeader()
    {
        $this->setMedia();
        $this->context->controller->addJS($this->_path.'/views/js/ContentProtector.js');
        $this->context->controller->addJS($this->_path.'/views/js/jQuery.addtocopy.js');
        $this->context->controller->addJS($this->_path.'/views/js/jxsecuritypanel.js');
        $this->context->controller->addCSS($this->_path.'/views/css/jxsecuritypanel.css');
    }
}
