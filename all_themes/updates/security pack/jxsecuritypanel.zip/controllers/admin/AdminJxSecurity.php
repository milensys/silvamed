<?php
/**
 * 2017-2018 Zemez
 *
 * JX Security Panel
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 *  @author    Zemez
 *  @copyright 2017-2018 Zemez
 *  @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */

include_once _PS_MODULE_DIR_ . 'jxsecuritypanel/jxsecuritypanel.php';

class AdminJxSecurityController extends ModuleAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->module = new Jxsecuritypanel();
    }

    public function ajaxProcessSaveSettings()
    {
        $configs = Tools::getValue('configs');
        $this->module->updateSettings($configs);
        if ((bool)$configs['JXSECURITY_CONTENT_HOTLINKING']) {
            $this->module->writeHtaccess();
        } else {
            $this->module->removeHtaccess();
        }
        die(json_encode(array('status' => 'true', 'message' => $this->module->l('Settings successfully saved!'))));
    }
}
