# JX Accelerated Mobile Page

v 0.1.2
FIX:
 - removed strict typification causing an issue between different PS versions

v 0.1.1
FIX:
 - removed usage of $_POST variable. Use Tools::getAllValues() instead