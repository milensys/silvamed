<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jxblog}prestashop>jxblog_e0c824c492bd0e3f2508f794dfd54e8d'] = 'The best module for Prestashop platform.';
$_MODULE['<{jxblog}prestashop>jxblog_270ea75d9da9ab2ba25886ccf538e86e'] = 'Are you sure that you want to delete the module? All related data will be deleted forever!';
