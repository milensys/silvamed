# JX Mega Menu

1.7.13
UPD: changed main menu class to avoid styles conflict with default prestashop menu
FIX: added override for color picker icon in the admin panel form

1.7.12
UPD: improved cooperation with JX Blog module. Now it works with blog categories tree

1.7.11
FIX: changed a logic of categories selection to avoid problems when the root category is disabled

1.7.10
FIX: added a checking if a top URL has any parameters

1.7.9
FIX: fixed a conflict in a jx blog post page if any post is added to menu

1.7.8
FIX: added verification whether a google script is defined(jxmegamenu-header.tpl)

1.7.7
FIX: fixed an issue with custom url validation

1.7.6
UPD: new functionality added: opportunity to use jx blog categories and posts in the menu

1.7.5
FIX: fixed some issues with non-existent variables

1.7.4
FIX: removed redundant pSql statements in objects filling to prevent an adding of slashes during recording to a database

1.7.3
UPD: added an opportunity to add Google Map API key and fixed the issue when no map is added but the script is included anyway