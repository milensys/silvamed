# JX Deal of Day

v 1.2.3 - added token to instant product search in admin panel
v 1.2.2 - added creation message in a back-end
v 1.2.1 - fixed an issue with special product's new label assigning
v 1.2.0 - reworked method of products selecting in order to avoid crashing when store has a lot of products (10000+)
v 1.0.1 - fixed issue when counters disappear after ajax page reloading