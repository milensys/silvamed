# Jx Header Account

FIX:
v 2.1.5
 - fixed an issue with a password during registration
 - added verification if link and gender parameters was transferred from Google API


FIX:
v 2.1.4 validation compliance is improved. Remove usage of global variable $_POST

FIX:
v 2.1.3 removed obsolete part of code which provided an error in facebook login page

UPD:
v 2.1.2 replaced checking newsletter module from blocknewsletter to ps_emailsubscription in reason of renaming the module

UPD:
v 2.1.1 added missed consent to a Header Account drop-down registration form

UPD:
v 2.1.0 implemented a compliance with "General Data Protection Regulation (GDPR)" and the official prestashop module

FIX:
v 2.0.1 solved a problem that appeared after facebook policy has changed to using strict redirect URL