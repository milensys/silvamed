# Jx Manufacturer Block

v 1.2.4
FIX:
  - improved fields validation

v 1.2.3
FIX:
  - added verification if any image type is assigned to brands

v 1.2.2
FIX:
  - validation compliance is improved

v 1.2.1
FIX:
 - fixed an issue during theme installation caused by wrong usage of count()